/*
 * Floricultura - cadastro de estoque com GTK 4
 * Adaptado do projeto original em C: lista duplamente encadeada
 * e persistencia no formato nome;preco;altura;tipo (lista.txt).
 *
 * Linux:   gcc -std=c11 -Wall -Wextra -O2 floricultura_gtk.c -o floricultura $(pkg-config --cflags --libs gtk4)
 * Windows: gcc -std=c11 -Wall -Wextra -O2 floricultura_gtk.c -o floricultura.exe $(pkg-config --cflags --libs gtk4)
 */

#include <gtk/gtk.h>
#include <math.h>
#include <string.h>

#ifdef G_OS_WIN32
#include <windows.h>
#endif

#if !GTK_CHECK_VERSION(4, 10, 0)
#error "Este programa requer GTK 4.10 ou superior."
#endif

#define ARQUIVO "lista.txt"
#define TAM_TEXTO 50

/* Mesmas estruturas e lista duplamente encadeada do codigo base. */
typedef struct {
    char nome[TAM_TEXTO];
    float preco;
    float altura;
    char tipo[TAM_TEXTO];
} Planta;

typedef struct Nodo {
    Planta planta;
    struct Nodo *ant;
    struct Nodo *prox;
} Nodo;

static Nodo *inicio = NULL;
static Nodo *fim = NULL;

typedef struct {
    GtkWindow *janela;
    GtkListBox *lista;
    GtkSearchEntry *busca;
    GtkEntry *entrada_nome;
    GtkEntry *entrada_tipo;
    GtkSpinButton *entrada_preco;
    GtkSpinButton *entrada_altura;
    GtkLabel *contador;
    GtkLabel *estado;
    GtkWidget *botao_alterar;
    GtkWidget *botao_excluir;
    Nodo *selecionado;
    gchar *caminho;
    gboolean alteracoes_pendentes;
} Interface;

static Interface ui = {0};

/* ------------------------ DADOS ------------------------ */

static Nodo *anexar_planta(const Planta *planta) {
    Nodo *novo = g_try_new0(Nodo, 1);
    if (!novo) return NULL;

    novo->planta = *planta;
    novo->ant = fim;
    novo->prox = NULL;

    if (fim) fim->prox = novo;
    else inicio = novo;

    fim = novo;
    return novo;
}

static void remover_planta(Nodo *p) {
    if (!p) return;

    if (p->ant) p->ant->prox = p->prox;
    else inicio = p->prox;

    if (p->prox) p->prox->ant = p->ant;
    else fim = p->ant;

    g_free(p);
}

static void limpar_estoque(void) {
    while (inicio) remover_planta(inicio);
}

static guint contar_plantas(void) {
    guint total = 0;
    for (Nodo *p = inicio; p; p = p->prox) total++;
    return total;
}

/* Usa a pasta do executavel, e nao a pasta atual do terminal. */
static gchar *caminho_do_arquivo(void) {
    gchar *executavel = NULL;

#ifdef G_OS_WIN32
    WCHAR nome_exe[32768];
    DWORD tam = GetModuleFileNameW(NULL, nome_exe, G_N_ELEMENTS(nome_exe));
    if (tam > 0 && tam < G_N_ELEMENTS(nome_exe))
        executavel = g_utf16_to_utf8((const gunichar2 *)nome_exe, -1,
                                     NULL, NULL, NULL);
#elif defined(__linux__)
    executavel = g_file_read_link("/proc/self/exe", NULL);
#endif

    gchar *diretorio = executavel ? g_path_get_dirname(executavel)
                                  : g_get_current_dir();
    gchar *arquivo = g_build_filename(diretorio, ARQUIVO, NULL);
    g_free(diretorio);
    g_free(executavel);
    return arquivo;
}

/* Aceita ponto (arquivo novo) ou virgula (arquivos legados). */
static gboolean converter_numero(const gchar *texto, float *saida) {
    if (!texto || !*texto) return FALSE;

    gchar *copia = g_strdup(texto);
    gchar *fim_numero = NULL;
    g_strstrip(copia);
    g_strdelimit(copia, ",", '.');

    double numero = g_ascii_strtod(copia, &fim_numero);
    gboolean valido = (fim_numero != copia && *fim_numero == '\0' &&
                        isfinite(numero) && numero >= 0 && numero <= G_MAXFLOAT);
    if (valido) *saida = (float)numero;
    g_free(copia);
    return valido;
}

static gboolean texto_valido(const gchar *texto) {
    if (!texto || !*texto || strlen(texto) >= TAM_TEXTO ||
        !g_utf8_validate(texto, -1, NULL) || strpbrk(texto, ";\r\n"))
        return FALSE;
    while (g_ascii_isspace(*texto)) texto++;
    return *texto != '\0';
}

static gboolean analisar_linha(const gchar *linha, Planta *planta) {
    gchar **campos = g_strsplit(linha, ";", -1);
    gboolean ok = FALSE;

    if (g_strv_length(campos) == 4) {
        gchar *nome = g_strstrip(campos[0]);
        gchar *tipo = g_strstrip(campos[3]);
        if (texto_valido(nome) && texto_valido(tipo) &&
            converter_numero(campos[1], &planta->preco) &&
            converter_numero(campos[2], &planta->altura)) {
            g_strlcpy(planta->nome, nome, sizeof(planta->nome));
            g_strlcpy(planta->tipo, tipo, sizeof(planta->tipo));
            ok = TRUE;
        }
    }

    g_strfreev(campos);
    return ok;
}

/* Substitui a lista apenas depois da leitura completa e valida do arquivo. */
static gboolean carregar_arquivo(guint *ignoradas, GError **erro) {
    gchar *conteudo = NULL;
    gsize tamanho = 0;
    *ignoradas = 0;

    if (!g_file_get_contents(ui.caminho, &conteudo, &tamanho, erro))
        return FALSE;

    /* Arquivos criados no console Windows podem usar Windows-1252. */
    if (!g_utf8_validate(conteudo, (gssize)tamanho, NULL)) {
        gchar *convertido = g_convert(conteudo, (gssize)tamanho,
                                     "UTF-8", "WINDOWS-1252",
                                     NULL, NULL, erro);
        if (!convertido) {
            g_free(conteudo);
            return FALSE;
        }
        g_free(conteudo);
        conteudo = convertido;
    }

    Nodo *novo_inicio = NULL;
    Nodo *novo_fim = NULL;
    gchar **linhas = g_strsplit(conteudo, "\n", -1);
    gboolean memoria_ok = TRUE;

    for (guint i = 0; linhas[i] != NULL; i++) {
        gchar *linha = g_strchomp(linhas[i]);
        if (!*linha) continue;

        Planta planta = {0};
        if (!analisar_linha(linha, &planta)) {
            (*ignoradas)++;
            continue;
        }

        Nodo *novo = g_try_new0(Nodo, 1);
        if (!novo) {
            memoria_ok = FALSE;
            break;
        }
        novo->planta = planta;
        novo->ant = novo_fim;
        if (novo_fim) novo_fim->prox = novo;
        else novo_inicio = novo;
        novo_fim = novo;
    }

    g_strfreev(linhas);
    g_free(conteudo);

    if (!memoria_ok) {
        while (novo_inicio) {
            Nodo *proximo = novo_inicio->prox;
            g_free(novo_inicio);
            novo_inicio = proximo;
        }
        g_set_error_literal(erro, G_FILE_ERROR, G_FILE_ERROR_NOMEM,
                            "Memoria insuficiente para carregar o arquivo.");
        return FALSE;
    }

    limpar_estoque();
    inicio = novo_inicio;
    fim = novo_fim;
    ui.alteracoes_pendentes = FALSE;
    return TRUE;
}

/* g_file_set_contents faz a gravacao integral e reporta erros de disco. */
static gboolean salvar_arquivo(GError **erro) {
    GString *texto = g_string_new(NULL);

    for (Nodo *p = inicio; p; p = p->prox) {
        char preco[64], altura[64];
        g_ascii_formatd(preco, sizeof(preco), "%.2f", p->planta.preco);
        g_ascii_formatd(altura, sizeof(altura), "%.2f", p->planta.altura);
        g_string_append_printf(texto, "%s;%s;%s;%s\n",
                               p->planta.nome, preco, altura, p->planta.tipo);
    }

    gboolean ok = g_file_set_contents(ui.caminho, texto->str,
                                      (gssize)texto->len, erro);
    if (ok) ui.alteracoes_pendentes = FALSE;
    g_string_free(texto, TRUE);
    return ok;
}

/* ---------------------- INTERFACE ---------------------- */

static GtkWidget *rotulo(const char *texto, const char *classe) {
    GtkWidget *label = gtk_label_new(texto);
    gtk_label_set_xalign(GTK_LABEL(label), 0.0f);
    if (classe) gtk_widget_add_css_class(label, classe);
    return label;
}

static void mensagem(const gchar *texto, gboolean erro) {
    gtk_label_set_text(ui.estado, texto);
    if (erro) gtk_widget_add_css_class(GTK_WIDGET(ui.estado), "erro");
    else gtk_widget_remove_css_class(GTK_WIDGET(ui.estado), "erro");
}

static gboolean nome_corresponde(const gchar *nome, const gchar *termo) {
    if (!termo || !*termo) return TRUE;
    gchar *nome_norm = g_utf8_casefold(nome, -1);
    gchar *termo_norm = g_utf8_casefold(termo, -1);
    gboolean resultado = strstr(nome_norm, termo_norm) != NULL;
    g_free(nome_norm);
    g_free(termo_norm);
    return resultado;
}

static gboolean filtrar_linha(GtkListBoxRow *linha, gpointer dados) {
    (void)dados;
    Nodo *planta = g_object_get_data(G_OBJECT(linha), "nodo");
    const char *busca = gtk_editable_get_text(GTK_EDITABLE(ui.busca));
    return planta && nome_corresponde(planta->planta.nome, busca);
}

static void atualizar_contador(void) {
    guint exibidas = 0, total = contar_plantas();
    const char *busca = gtk_editable_get_text(GTK_EDITABLE(ui.busca));
    for (Nodo *p = inicio; p; p = p->prox)
        if (nome_corresponde(p->planta.nome, busca)) exibidas++;

    gchar *texto = g_strdup_printf("%u de %u planta(s) exibida(s)",
                                   exibidas, total);
    gtk_label_set_text(ui.contador, texto);
    g_free(texto);
}

static void habilitar_edicao(gboolean ativa) {
    gtk_widget_set_sensitive(ui.botao_alterar, ativa);
    gtk_widget_set_sensitive(ui.botao_excluir, ativa);
}

static void limpar_formulario(void) {
    ui.selecionado = NULL;
    gtk_editable_set_text(GTK_EDITABLE(ui.entrada_nome), "");
    gtk_editable_set_text(GTK_EDITABLE(ui.entrada_tipo), "");
    gtk_spin_button_set_value(ui.entrada_preco, 0);
    gtk_spin_button_set_value(ui.entrada_altura, 0);
    habilitar_edicao(FALSE);
}

static void selecionar_linha(GtkListBox *lista, GtkListBoxRow *linha,
                            gpointer dados) {
    (void)lista;
    (void)dados;
    if (!linha) {
        ui.selecionado = NULL;
        habilitar_edicao(FALSE);
        return;
    }

    Nodo *n = g_object_get_data(G_OBJECT(linha), "nodo");
    if (!n) return;
    ui.selecionado = n;
    gtk_editable_set_text(GTK_EDITABLE(ui.entrada_nome), n->planta.nome);
    gtk_editable_set_text(GTK_EDITABLE(ui.entrada_tipo), n->planta.tipo);
    gtk_spin_button_set_value(ui.entrada_preco, n->planta.preco);
    gtk_spin_button_set_value(ui.entrada_altura, n->planta.altura);
    habilitar_edicao(TRUE);
}

static GtkWidget *celula(const char *texto, int largura, gboolean forte) {
    GtkWidget *label = rotulo(texto, forte ? "celula-nome" : "celula");
    gtk_widget_set_size_request(label, largura, -1);
    gtk_label_set_ellipsize(GTK_LABEL(label), PANGO_ELLIPSIZE_END);
    gtk_widget_set_hexpand(label, TRUE);
    return label;
}

static void atualizar_lista(void) {
    gtk_list_box_unselect_all(ui.lista);
    ui.selecionado = NULL;
    habilitar_edicao(FALSE);

    GtkListBoxRow *linha;
    while ((linha = gtk_list_box_get_row_at_index(ui.lista, 0)) != NULL)
        gtk_list_box_remove(ui.lista, GTK_WIDGET(linha));

    for (Nodo *p = inicio; p; p = p->prox) {
        char preco[64], altura[64];
        g_snprintf(preco, sizeof(preco), "R$ %.2f", p->planta.preco);
        g_snprintf(altura, sizeof(altura), "%.2f cm", p->planta.altura);

        GtkWidget *linha_widget = gtk_list_box_row_new();
        GtkWidget *conteudo = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 12);
        gtk_widget_set_margin_top(conteudo, 13);
        gtk_widget_set_margin_bottom(conteudo, 13);
        gtk_widget_set_margin_start(conteudo, 12);
        gtk_widget_set_margin_end(conteudo, 12);
        gtk_box_append(GTK_BOX(conteudo), celula(p->planta.nome, 175, TRUE));
        gtk_box_append(GTK_BOX(conteudo), celula(preco, 85, FALSE));
        gtk_box_append(GTK_BOX(conteudo), celula(altura, 85, FALSE));
        gtk_box_append(GTK_BOX(conteudo), celula(p->planta.tipo, 135, FALSE));
        gtk_list_box_row_set_child(GTK_LIST_BOX_ROW(linha_widget), conteudo);
        gtk_widget_add_css_class(linha_widget, "linha-planta");
        g_object_set_data(G_OBJECT(linha_widget), "nodo", p);
        gtk_list_box_append(ui.lista, linha_widget);
    }

    gtk_list_box_invalidate_filter(ui.lista);
    atualizar_contador();
}

static gboolean ler_formulario(Planta *planta) {
    const gchar *nome = gtk_editable_get_text(GTK_EDITABLE(ui.entrada_nome));
    const gchar *tipo = gtk_editable_get_text(GTK_EDITABLE(ui.entrada_tipo));

    if (!texto_valido(nome) || !texto_valido(tipo)) {
        mensagem("Nome e tipo sao obrigatorios, com ate 49 bytes, sem ';'.", TRUE);
        return FALSE;
    }

    /* Confirma texto digitado nas caixas numericas antes de ler o valor. */
    gtk_spin_button_update(ui.entrada_preco);
    gtk_spin_button_update(ui.entrada_altura);
    double preco = gtk_spin_button_get_value(ui.entrada_preco);
    double altura = gtk_spin_button_get_value(ui.entrada_altura);
    if (!isfinite(preco) || !isfinite(altura) || preco < 0 || altura < 0) {
        mensagem("Preco e altura devem ser numeros nao negativos.", TRUE);
        return FALSE;
    }

    memset(planta, 0, sizeof(*planta));
    g_strlcpy(planta->nome, nome, sizeof(planta->nome));
    g_strlcpy(planta->tipo, tipo, sizeof(planta->tipo));
    planta->preco = (float)preco;
    planta->altura = (float)altura;
    return TRUE;
}

static void confirmar_gravacao(const char *sucesso) {
    GError *erro = NULL;
    ui.alteracoes_pendentes = TRUE;
    if (salvar_arquivo(&erro)) {
        mensagem(sucesso, FALSE);
    } else {
        gchar *texto = g_strdup_printf(
            "Alteracao feita na memoria, mas NAO salva em disco: %s",
            erro ? erro->message : "erro desconhecido");
        mensagem(texto, TRUE);
        g_free(texto);
        g_clear_error(&erro);
    }
}

static void ao_buscar(GtkSearchEntry *busca, gpointer dados) {
    (void)busca;
    (void)dados;
    gtk_list_box_unselect_all(ui.lista);
    limpar_formulario();
    gtk_list_box_invalidate_filter(ui.lista);
    atualizar_contador();
}

static void ao_novo(GtkButton *botao, gpointer dados) {
    (void)botao;
    (void)dados;
    gtk_editable_set_text(GTK_EDITABLE(ui.busca), "");
    gtk_list_box_unselect_all(ui.lista);
    limpar_formulario();
    gtk_widget_grab_focus(GTK_WIDGET(ui.entrada_nome));
    mensagem("Preencha os campos e clique em Cadastrar planta.", FALSE);
}

static void ao_cadastrar(GtkButton *botao, gpointer dados) {
    (void)botao;
    (void)dados;
    Planta planta;
    if (!ler_formulario(&planta)) return;
    if (!anexar_planta(&planta)) {
        mensagem("Memoria insuficiente para cadastrar a planta.", TRUE);
        return;
    }

    gtk_editable_set_text(GTK_EDITABLE(ui.busca), "");
    atualizar_lista();
    limpar_formulario();
    confirmar_gravacao("Planta cadastrada e estoque salvo em lista.txt.");
}

static void ao_alterar(GtkButton *botao, gpointer dados) {
    (void)botao;
    (void)dados;
    if (!ui.selecionado) {
        mensagem("Selecione uma planta na lista antes de alterar.", TRUE);
        return;
    }

    Planta alterada;
    if (!ler_formulario(&alterada)) return;
    ui.selecionado->planta = alterada;

    gtk_editable_set_text(GTK_EDITABLE(ui.busca), "");
    atualizar_lista();
    limpar_formulario();
    confirmar_gravacao("Planta alterada e estoque salvo em lista.txt.");
}

static void ao_confirmar_exclusao(GObject *origem, GAsyncResult *resultado,
                                  gpointer dados) {
    GtkAlertDialog *dialogo = GTK_ALERT_DIALOG(origem);
    GError *erro = NULL;
    int resposta = gtk_alert_dialog_choose_finish(dialogo, resultado, &erro);
    Nodo *n = dados;

    if (resposta == 1 && !erro && n) {
        gtk_list_box_unselect_all(ui.lista);
        ui.selecionado = NULL;
        remover_planta(n);
        atualizar_lista();
        limpar_formulario();
        confirmar_gravacao("Planta excluida e estoque salvo em lista.txt.");
    }
    g_clear_error(&erro);
}

static void ao_excluir(GtkButton *botao, gpointer dados) {
    (void)botao;
    (void)dados;
    if (!ui.selecionado) {
        mensagem("Selecione uma planta antes de excluir.", TRUE);
        return;
    }

    GtkAlertDialog *dialogo = gtk_alert_dialog_new(
        "Excluir a planta '%s'?", ui.selecionado->planta.nome);
    const char *botoes[] = {"Cancelar", "Excluir", NULL};
    gtk_alert_dialog_set_buttons(dialogo, botoes);
    gtk_alert_dialog_set_detail(dialogo,
        "Esta operacao remove o cadastro e atualiza lista.txt.");
    gtk_alert_dialog_set_cancel_button(dialogo, 0);
    gtk_alert_dialog_set_default_button(dialogo, 0);
    gtk_alert_dialog_set_modal(dialogo, TRUE);
    gtk_alert_dialog_choose(dialogo, ui.janela, NULL,
                            ao_confirmar_exclusao, ui.selecionado);
    g_object_unref(dialogo);
}

static void ao_salvar(GtkButton *botao, gpointer dados) {
    (void)botao;
    (void)dados;
    GError *erro = NULL;
    if (salvar_arquivo(&erro)) {
        mensagem("Estoque salvo em lista.txt com sucesso.", FALSE);
    } else {
        gchar *texto = g_strdup_printf("Erro ao salvar arquivo: %s",
                                          erro ? erro->message : "erro desconhecido");
        mensagem(texto, TRUE);
        g_free(texto);
        g_clear_error(&erro);
    }
}

static void ao_recarregar(GtkButton *botao, gpointer dados) {
    (void)botao;
    (void)dados;
    if (ui.alteracoes_pendentes) {
        mensagem("Ha alteracoes nao salvas. Use Salvar antes de recarregar.", TRUE);
        return;
    }

    GError *erro = NULL;
    guint ignoradas = 0;
    if (carregar_arquivo(&ignoradas, &erro)) {
        gtk_editable_set_text(GTK_EDITABLE(ui.busca), "");
        atualizar_lista();
        limpar_formulario();
        if (ignoradas) {
            gchar *texto = g_strdup_printf(
                "Arquivo carregado. %u linha(s) invalida(s) ignorada(s).",
                ignoradas);
            mensagem(texto, TRUE);
            g_free(texto);
        } else {
            mensagem("Estoque recarregado do arquivo lista.txt.", FALSE);
        }
    } else {
        gchar *texto = g_strdup_printf("Nao foi possivel carregar lista.txt: %s",
                                          erro ? erro->message : "erro desconhecido");
        mensagem(texto, TRUE);
        g_free(texto);
        g_clear_error(&erro);
    }
}

static GtkWidget *botao_acao(const char *texto, const char *classe,
                             GCallback funcao) {
    GtkWidget *botao = gtk_button_new_with_label(texto);
    if (classe) gtk_widget_add_css_class(botao, classe);
    gtk_widget_set_hexpand(botao, TRUE);
    g_signal_connect(botao, "clicked", funcao, NULL);
    return botao;
}

static GtkWidget *linha_cabecalho(void) {
    GtkWidget *linha = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 12);
    gtk_widget_add_css_class(linha, "cabecalho-tabela");
    gtk_widget_set_margin_start(linha, 12);
    gtk_widget_set_margin_end(linha, 12);
    gtk_widget_set_margin_top(linha, 10);
    gtk_widget_set_margin_bottom(linha, 10);
    gtk_box_append(GTK_BOX(linha), celula("PLANTA", 175, TRUE));
    gtk_box_append(GTK_BOX(linha), celula("PRECO", 85, TRUE));
    gtk_box_append(GTK_BOX(linha), celula("ALTURA", 85, TRUE));
    gtk_box_append(GTK_BOX(linha), celula("TIPO", 135, TRUE));
    return linha;
}

static GtkWidget *campo_texto(GtkEntry **destino, const char *titulo,
                              const char *placeholder, GtkBox *painel) {
    gtk_box_append(painel, rotulo(titulo, "campo-label"));
    GtkWidget *campo = gtk_entry_new();
    gtk_entry_set_placeholder_text(GTK_ENTRY(campo), placeholder);
    gtk_entry_set_max_length(GTK_ENTRY(campo), TAM_TEXTO - 1);
    gtk_widget_set_hexpand(campo, TRUE);
    gtk_widget_add_css_class(campo, "campo");
    gtk_box_append(painel, campo);
    *destino = GTK_ENTRY(campo);
    return campo;
}

static void campo_numero(GtkSpinButton **destino, const char *titulo,
                         GtkBox *painel) {
    gtk_box_append(painel, rotulo(titulo, "campo-label"));
    GtkWidget *campo = gtk_spin_button_new_with_range(0.0, 1000000000.0, 0.01);
    gtk_spin_button_set_digits(GTK_SPIN_BUTTON(campo), 2);
    gtk_spin_button_set_numeric(GTK_SPIN_BUTTON(campo), TRUE);
    gtk_widget_add_css_class(campo, "campo");
    gtk_box_append(painel, campo);
    *destino = GTK_SPIN_BUTTON(campo);
}

static void aplicar_estilo(void) {
    const char *css =
        "window { background: #f3f7f4; }"
        ".barra-topo { background: #153e30; border-radius: 14px; padding: 18px 24px; }"
        ".titulo-app { color: #ffffff; font-size: 25px; font-weight: 800; }"
        ".subtitulo-app { color: #c6e5d6; font-size: 12px; }"
        ".cartao { background: #ffffff; border: 1px solid #dbe7df; border-radius: 14px; padding: 20px; }"
        ".titulo-card { color: #183d30; font-size: 19px; font-weight: 700; }"
        ".texto-suave { color: #6f8377; font-size: 12px; }"
        ".campo-label { font-size: 12px; font-weight: 700; color: #4a6455; margin-top: 7px; }"
        ".campo { min-height: 34px; }"
        ".primario { background: #23734e; color: white; border-radius: 8px; min-height: 40px; font-weight: 700; }"
        ".primario:hover { background: #185b3c; }"
        ".perigo { background: #b94f49; color: white; border-radius: 8px; min-height: 38px; }"
        ".perigo:hover { background: #9b3936; }"
        ".secundario { border-radius: 8px; min-height: 38px; }"
        ".cabecalho-tabela { background: #f0f6f2; border-radius: 8px; }"
        ".cabecalho-tabela label { color: #536c5c; font-size: 11px; font-weight: 700; }"
        ".linha-planta { border-bottom: 1px solid #edf0ed; }"
        ".linha-planta:selected { background: #def1e5; }"
        ".celula-nome { color: #1c4532; font-weight: 700; }"
        ".celula { color: #54665a; }"
        ".estado { color: #277247; font-size: 12px; }"
        ".estado.erro { color: #b63333; font-weight: 700; }";

    GtkCssProvider *provider = gtk_css_provider_new();
#if GTK_CHECK_VERSION(4, 12, 0)
    gtk_css_provider_load_from_string(provider, css);
#else
    gtk_css_provider_load_from_data(provider, css, -1);
#endif
    gtk_style_context_add_provider_for_display(
        gdk_display_get_default(), GTK_STYLE_PROVIDER(provider),
        GTK_STYLE_PROVIDER_PRIORITY_APPLICATION);
    g_object_unref(provider);
}

static void ativar(GtkApplication *app, gpointer dados) {
    (void)dados;
    ui.caminho = caminho_do_arquivo();
    ui.janela = GTK_WINDOW(gtk_application_window_new(app));
    gtk_window_set_title(ui.janela, "Floricultura | Controle de estoque");
    gtk_window_set_default_size(ui.janela, 1180, 730);
    gtk_widget_set_size_request(GTK_WIDGET(ui.janela), 950, 590);
    aplicar_estilo();

    GtkWidget *raiz = gtk_box_new(GTK_ORIENTATION_VERTICAL, 17);
    gtk_widget_set_margin_start(raiz, 20);
    gtk_widget_set_margin_end(raiz, 20);
    gtk_widget_set_margin_top(raiz, 20);
    gtk_widget_set_margin_bottom(raiz, 20);
    gtk_window_set_child(ui.janela, raiz);

    GtkWidget *topo = gtk_box_new(GTK_ORIENTATION_VERTICAL, 3);
    gtk_widget_add_css_class(topo, "barra-topo");
    gtk_box_append(GTK_BOX(topo), rotulo("FLORICULTURA", "titulo-app"));
    gtk_box_append(GTK_BOX(topo), rotulo("Controle de estoque  |  Cadastro de plantas", "subtitulo-app"));
    gtk_box_append(GTK_BOX(raiz), topo);

    GtkWidget *principal = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 16);
    gtk_widget_set_vexpand(principal, TRUE);
    gtk_box_append(GTK_BOX(raiz), principal);

    GtkWidget *esquerda = gtk_box_new(GTK_ORIENTATION_VERTICAL, 13);
    gtk_widget_add_css_class(esquerda, "cartao");
    gtk_widget_set_hexpand(esquerda, TRUE);
    gtk_widget_set_vexpand(esquerda, TRUE);
    gtk_box_append(GTK_BOX(principal), esquerda);

    GtkWidget *titulos = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 10);
    gtk_box_append(GTK_BOX(titulos), rotulo("Plantas cadastradas", "titulo-card"));
    ui.contador = GTK_LABEL(rotulo("", "texto-suave"));
    gtk_widget_set_hexpand(GTK_WIDGET(ui.contador), TRUE);
    gtk_label_set_xalign(ui.contador, 1.0f);
    gtk_box_append(GTK_BOX(titulos), GTK_WIDGET(ui.contador));
    gtk_box_append(GTK_BOX(esquerda), titulos);

    ui.busca = GTK_SEARCH_ENTRY(gtk_search_entry_new());
    gtk_widget_set_hexpand(GTK_WIDGET(ui.busca), TRUE);
    gtk_search_entry_set_placeholder_text(ui.busca, "Buscar planta pelo nome...");
    gtk_box_append(GTK_BOX(esquerda), GTK_WIDGET(ui.busca));

    gtk_box_append(GTK_BOX(esquerda), linha_cabecalho());
    GtkWidget *rolagem = gtk_scrolled_window_new();
    gtk_widget_set_vexpand(rolagem, TRUE);
    gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(rolagem),
                                    GTK_POLICY_AUTOMATIC, GTK_POLICY_AUTOMATIC);
    ui.lista = GTK_LIST_BOX(gtk_list_box_new());
    gtk_list_box_set_selection_mode(ui.lista, GTK_SELECTION_SINGLE);
    gtk_list_box_set_filter_func(ui.lista, filtrar_linha, NULL, NULL);
    gtk_list_box_set_placeholder(ui.lista,
        rotulo("Nenhuma planta encontrada. Cadastre ou altere sua busca.", "texto-suave"));
    gtk_scrolled_window_set_child(GTK_SCROLLED_WINDOW(rolagem), GTK_WIDGET(ui.lista));
    gtk_box_append(GTK_BOX(esquerda), rolagem);

    GtkWidget *direita = gtk_box_new(GTK_ORIENTATION_VERTICAL, 10);
    gtk_widget_set_size_request(direita, 300, -1);
    gtk_widget_add_css_class(direita, "cartao");
    gtk_box_append(GTK_BOX(principal), direita);

    gtk_box_append(GTK_BOX(direita), rotulo("Cadastro de planta", "titulo-card"));
    gtk_box_append(GTK_BOX(direita), rotulo(
        "Selecione uma planta na lista para editar ou excluir.", "texto-suave"));
    campo_texto(&ui.entrada_nome, "Nome da planta", "Ex.: Rosa vermelha", GTK_BOX(direita));
    campo_numero(&ui.entrada_preco, "Preco (R$)", GTK_BOX(direita));
    campo_numero(&ui.entrada_altura, "Altura (cm)", GTK_BOX(direita));
    campo_texto(&ui.entrada_tipo, "Tipo", "Ex.: Ornamental", GTK_BOX(direita));

    GtkWidget *espacador = gtk_box_new(GTK_ORIENTATION_VERTICAL, 1);
    gtk_widget_set_vexpand(espacador, TRUE);
    gtk_box_append(GTK_BOX(direita), espacador);

    gtk_box_append(GTK_BOX(direita),
        botao_acao("Cadastrar planta", "primario", G_CALLBACK(ao_cadastrar)));
    ui.botao_alterar = botao_acao("Salvar alteracoes", "secundario", G_CALLBACK(ao_alterar));
    gtk_box_append(GTK_BOX(direita), ui.botao_alterar);
    ui.botao_excluir = botao_acao("Excluir selecionada", "perigo", G_CALLBACK(ao_excluir));
    gtk_box_append(GTK_BOX(direita), ui.botao_excluir);
    gtk_box_append(GTK_BOX(direita),
        botao_acao("Limpar campos / Nova", "secundario", G_CALLBACK(ao_novo)));
    habilitar_edicao(FALSE);

    GtkWidget *rodape = gtk_box_new(GTK_ORIENTATION_VERTICAL, 6);
    gtk_box_append(GTK_BOX(raiz), rodape);
    GtkWidget *acoes = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 12);
    gtk_box_append(GTK_BOX(acoes), botao_acao("Salvar arquivo TXT", "secundario", G_CALLBACK(ao_salvar)));
    gtk_box_append(GTK_BOX(acoes), botao_acao("Recarregar arquivo TXT", "secundario", G_CALLBACK(ao_recarregar)));
    gtk_box_append(GTK_BOX(rodape), acoes);
    ui.estado = GTK_LABEL(rotulo("", "estado"));
    gtk_label_set_wrap(ui.estado, TRUE);
    gtk_box_append(GTK_BOX(rodape), GTK_WIDGET(ui.estado));
    gchar *local = g_strdup_printf("Arquivo de dados: %s", ui.caminho);
    GtkWidget *indicacao = rotulo(local, "texto-suave");
    gtk_label_set_ellipsize(GTK_LABEL(indicacao), PANGO_ELLIPSIZE_MIDDLE);
    gtk_box_append(GTK_BOX(rodape), indicacao);
    g_free(local);

    g_signal_connect(ui.lista, "row-selected", G_CALLBACK(selecionar_linha), NULL);
    g_signal_connect(ui.busca, "search-changed", G_CALLBACK(ao_buscar), NULL);

    GError *erro = NULL;
    guint ignoradas = 0;
    if (carregar_arquivo(&ignoradas, &erro)) {
        if (ignoradas) {
            gchar *aviso = g_strdup_printf(
                "Estoque carregado; %u linha(s) invalida(s) ignorada(s).",
                ignoradas);
            mensagem(aviso, TRUE);
            g_free(aviso);
        } else mensagem("Estoque carregado. Selecione ou cadastre uma planta.", FALSE);
    } else if (g_error_matches(erro, G_FILE_ERROR, G_FILE_ERROR_NOENT)) {
        mensagem("Estoque vazio. O arquivo lista.txt sera criado ao cadastrar.", FALSE);
    } else {
        gchar *aviso = g_strdup_printf("Nao foi possivel ler lista.txt: %s",
                                          erro ? erro->message : "erro desconhecido");
        mensagem(aviso, TRUE);
        g_free(aviso);
    }
    g_clear_error(&erro);
    atualizar_lista();
    gtk_window_present(ui.janela);
}

int main(int argc, char **argv) {
    GtkApplication *app = gtk_application_new(
        "br.com.floricultura.estoque", G_APPLICATION_DEFAULT_FLAGS);
    g_signal_connect(app, "activate", G_CALLBACK(ativar), NULL);
    int status = g_application_run(G_APPLICATION(app), argc, argv);
    limpar_estoque();
    g_clear_pointer(&ui.caminho, g_free);
    g_object_unref(app);
    return status;
}
